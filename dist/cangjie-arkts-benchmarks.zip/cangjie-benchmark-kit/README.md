# Cangjie and ArkTS benchmark kit

This archive contains the instrumented benchmarks, their full DevEco application, the original HTML presentation, and its embedded chart scripts, styles, images, and recorded measurements. It also includes the portable optimization skill and the self-contained implementation handoff.

## Contents

| Path | Purpose |
| --- | --- |
| `benchmarks/interop_opt_bench/interop.html` | Original standalone presentation; open directly in a browser |
| `benchmarks/interop_opt_bench/externBchm/` | Full tracked DevEco project with Cangjie instrumentation, ArkTS runners, autorun, CSV export, demo pages, declarations, resources, and build configuration |
| `presentation_sources/interop.inline.js` | Exact JavaScript extracted from the presentation, including chart rendering, tables, highlighting, navigation, and the `DATA` object |
| `presentation_sources/interop.inline.css` | Exact embedded stylesheet |
| `presentation_sources/recorded-data.json` | JSON snapshot of the presentation's recorded `DATA` object |
| `scripts/extract_html_assets.py` | Added utility to extract the page's inline scripts and styles |
| `scripts/export_presentation_data.js` | Added utility to export the recorded `DATA` object as JSON |
| `scripts/summarize_results.py` | Added utility to summarize newly collected benchmark CSV or hilog results |
| `docs/interop_optimization_handoff.md` | Applicability rules, complete before and after code, helper reuse rules, and verification instructions |
| `skills/cangjie-arkts-optimize/` | Portable agent skill, bundled handoff, and example extraction utility |
| `MANIFEST.json` | Source revision, file origins, modifications, and SHA256 checksums |

The HTML has one inline script, one inline stylesheet, and two embedded JPEG images. It has no external resource dependencies. The extracted `.js` and `.css` are convenience copies: the original HTML already contains them and does not import these files.

The displayed medians and confidence intervals are recorded values. The page renders charts and calculates displayed ratios from its `DATA` object; it does not launch benchmarks, read CSV, or calculate bootstrap intervals from raw runs. The repository contains no original raw result logs or offline bootstrap-generation script. The added summary utility is separate from the original presentation and does not reproduce those intervals or rewrite the slides.

## Running the benchmark application

Open `benchmarks/interop_opt_bench/externBchm` in DevEco Studio. The source declares Cangjie 1.1.3, project model 6.1.1, and target and compatible SDK `6.1.1(24)`. Configure the installed SDK, dependencies, build target, and your own device signing in DevEco. Machine-specific signing material and the product's signing reference have been removed from the archive's root `build-profile.json5`; source files in the originating repository have not been changed.

Build and install the application using your existing DevEco workflow. For comparable timings, use the same release configuration and device for baseline and optimized measurements. The app's main page provides buttons for each benchmark and quick smoke runs. The benchmarks need the OHOS SDK and a device or emulator; they are not desktop Cangjie programs.

The included `EntryAbility.ets` and `pages/Index.ets` also support an `autorun` parameter. The source uses this ability-manager command convention:

```bash
aa start -a EntryAbility -b com.example.externbchm --ps autorun b03,quick
```

Run it through the device's ability-manager shell using your configured SDK/device tools. Useful autorun strings include:

| Workload | Autorun parameter |
| --- | --- |
| Property access smoke run | `b03,quick` |
| Futures with 21 repetitions | `b01,reps21` |
| Batching with 30 repetitions | `b01,batch,reps30` |
| Scoped temporaries | `b07,reps25` |
| String caches | `b08,reps32` |
| Search batching comparison | `b09,batch,desc200,reps100` |
| Graph layout | `b12,reps8` |
| All smoke runs | `all,quick` |

Options apply to each selected benchmark; inspect its ArkTS runner before combining workloads with special options. Some quick runs reduce repetitions without reducing all input sizes. These are workload examples, not commands that reproduce every slide's recorded measurement session.

## Instrumentation and results

`harness.cj` uses `MonoTime` for elapsed nanoseconds. B01 also records summed worker waiting and work time. B12 records frame wall time, ArkTS-thread time, and computation time. B05 and B06 provide additional GC and persistence diagnostics. ArkTS drivers perform repetitions, warmups where implemented, and variant rotation or randomized ordering where implemented, and log checksums and applicable error counts.

`Log.ets` emits `BENCH,...` records to hilog and a supplied sink. The main page keeps a copy and writes `<application filesDir>/results.csv` at the end of a run. It strips the leading `BENCH,` from CSV lines. This file is the authoritative copy because hilog can rate-limit bursts. Retrieve it with your device or debugger tooling. Copy or rename it after each run: the next run truncates the file.

The app logs `BENCH_DONE` after saving the CSV, so that marker is generally not in the saved file. `BENCH_ERROR` indicates a benchmark exception. A missing completion marker in hilog does not prove failure if logging was rate-limited. There is no bundled HAP binary, host device collector, signing certificate, or SDK installation.

Run the added analyzer on a saved CSV or hilog capture:

```bash
python3 scripts/summarize_results.py results.csv --benchmark b03 --metric ns_per_path --group-by n,d,k,variant
python3 scripts/summarize_results.py results.csv --benchmark b07 --metric ns_per_elem --group-by prog,n,passes,variant
python3 scripts/summarize_results.py results.csv --benchmark b08 --metric ns_per_record --group-by n,u,variant
python3 scripts/summarize_results.py results.csv --benchmark b12 --metric ms_frame --group-by N,variant --drop-first-frame
```

The analyzer follows each benchmark's header, supports repeated headers, and groups by the fields you specify. Specify all workload-defining fields and enough optimization fields to distinguish variants. In B01, include `d` for a futures sweep and `b` for a batching sweep. In search, include the optimization flags, thread count, batching parameter, and input lengths. B03 labels all getter variants `calls`, so include `k` to distinguish one call per level, partial paths, and whole-path coalescing.

Rows within the same input file, group, and `rep` are reduced to one median per run, which prevents graph frames from being counted as independent runs. It then reports the median and min and max across those run medians. Separate collected sessions belong in separate files; multiple input files are supported. `--drop-first-frame` excludes frame zero when a `frame` column exists. Failed `ok` checks, nonzero `errors`, and malformed selected rows cause an error; validate checksums against the expected outputs separately. Other benchmark tables and diagnostic lines are ignored.

Metric units are preserved: `ns_*` is nanoseconds, `us_*` is microseconds, and `ms_*` is milliseconds. Compare matching workload medians using baseline time divided by optimized time. The analyzer reports observed spread, not a confidence interval, and cannot establish semantic equivalence from timings.

## Exporting the presentation sources again

Python 3.9 or newer runs the Python utilities; they use only the standard library. Node.js runs the recorded-data exporter and has no package dependencies.

```bash
python3 scripts/extract_html_assets.py benchmarks/interop_opt_bench/interop.html /tmp/new-presentation-sources
node scripts/export_presentation_data.js benchmarks/interop_opt_bench/interop.html > /tmp/recorded-data.json
```

The source extractor refuses an existing destination. The data exporter evaluates only the bundled `DATA` object literal, not the chart or navigation code. The exported JSON preserves the values and structure used by the presentation.

## Using the skill on another codebase

Copy the complete `skills/cangjie-arkts-optimize` folder into the other repository's skill location and invoke it to find, apply, and measure the relevant optimizations. The full benchmark project here includes the autorun and CSV persistence code; the smaller skill's 22-file example extraction does not include those application entry files. Refer the receiving agent to this kit when it needs the complete application harness.

## Provenance and validation

Original project and presentation files are from revision `37d658d26440254d3c653dc82d2fb64f9511db8d` of `cangjie_extern`. `MANIFEST.json` identifies copied files, extracted resources, added utilities, and the sanitized build configuration.

The package's source copies, HTML dependencies, extracted resources, JavaScript syntax, recorded-data export, analyzer behavior, and ZIP integrity were verified on the host. Building and running the OHOS application requires your SDK and device configuration.
