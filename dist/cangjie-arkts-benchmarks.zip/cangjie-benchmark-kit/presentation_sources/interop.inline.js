
// ---------------------------------------------------------------------------
// Data (µs). Update here; charts and tables are generated from it.
// ---------------------------------------------------------------------------
const DATA = {
  // Direct rows: arkts = the operation in pure ArkTS, cj = the same operation from Cangjie on the ArkTS
  // thread (constants cached where the variant exists). Posted row: one Cangjie value.
  tiers: [
    { label: 'Array element read', arkts: 0.004, cj: 0.23 },
    { label: 'Property read', arkts: 0.005, cj: 0.43 },
    { label: 'Function call, 1 argument', arkts: 0.019, cj: 0.86 },
    { label: 'Method call', arkts: 0.034, cj: 0.94 },
    { label: 'Create object with 2 fields', arkts: 0.061, cj: 1.17 },
    { label: 'Call from another thread', posted: 112.9 },
  ],
  // 95% intervals (bootstrap over runs) for the line charts, same order as the series: [low, high].
  // µs charts: interval of the median; speedup charts: interval of the ratio of medians.
  ci: {
    fut1: { 'w = 0': [[103.0, 119.0], [86.1, 103.5], [40.5, 54.0], [28.3, 36.9], [17.7, 21.9], [11.1, 12.0], [8.1, 13.2]],
            'w = 10 µs': [[103.2, 117.7], [100.4, 108.9], [53.9, 65.4], [30.8, 38.5], [20.1, 28.6], [19.7, 26.4], [19.4, 20.3]],
            'w = 50 µs': [[158.3, 202.6], [155.6, 232.5], [71.3, 75.4], [65.7, 66.6], [64.3, 65.5], [64.3, 65.6], [63.4, 64.4]] },
    fut4: { 'w = 0': [[19.9, 21.6], [18.9, 20.7], [13.2, 14.0], [10.4, 11.0], [9.5, 10.1], [8.3, 9.3], [7.9, 8.5]],
            'w = 10 µs': [[21.9, 25.7], [23.2, 26.2], [13.7, 15.5], [12.0, 13.2], [10.5, 11.0], [9.7, 10.2], [9.1, 9.9]],
            'w = 50 µs': [[31.9, 34.9], [31.3, 31.8], [17.0, 17.1], [16.7, 16.9], [16.7, 16.9], [16.7, 17.0], [16.6, 16.7]] },
    bat1: { 'w = 0': [[100.0, 146.8], [75.4, 122.1], [40.7, 59.9], [23.1, 36.6], [21.0, 23.1], [13.6, 15.9]],
            'w = 10 µs': [[111.7, 125.2], [101.2, 119.0], [66.0, 84.1], [47.9, 54.8], [32.8, 36.7], [23.7, 27.7]],
            'w = 50 µs': [[168.3, 245.2], [188.4, 239.4], [113.4, 148.3], [97.2, 111.3], [77.7, 83.7], [68.0, 72.6]] },
    bat4: { 'w = 0': [[20.1, 22.0], [18.7, 20.8], [10.0, 11.5], [5.9, 6.9], [4.0, 4.4], [1.9, 2.9]],
            'w = 10 µs': [[21.3, 25.4], [21.0, 25.2], [11.6, 14.8], [8.2, 9.1], [6.2, 7.3], [5.1, 5.7]],
            'w = 50 µs': [[31.4, 32.3], [30.1, 31.8], [23.0, 23.3], [18.9, 19.1], [16.2, 16.9], [15.7, 16.0]] },
    // B02 speedups, main thread work 100% .. 0% (8 runs per point)
    mix: { '1 thread': [[0.75, 1.13], [4.18, 5.98], [4.36, 6.78], [4.32, 8.19], [4.36, 7.38], [3.88, 7.28]],
           '4 threads': [[0.88, 0.99], [1.57, 2.02], [1.80, 2.30], [2.13, 2.50], [1.99, 2.44], [1.96, 2.31]] },
    bunch: { 'naive': [[0.63, 0.65], [1.36, 1.42], [2.35, 2.57], [4.98, 5.57]],
             'coalesced': [[0.84, 0.88], [0.89, 0.90], [0.83, 0.89], [0.85, 0.89]] },
    // objects + strings combined: ratio of summed medians, bootstrap over both benchmarks
    temp: { optimised: [[1.30, 1.69], [1.31, 1.91], [1.29, 1.66], [1.27, 1.70]] },
    cache: { 'names + values cached': [[1.55, 2.27], [1.38, 1.88], [1.57, 1.75], [1.60, 1.76], [1.00, 1.53]],
             'names cached': [[1.08, 1.63], [0.95, 1.35], [0.96, 1.20], [1.14, 1.27], [1.07, 1.50]] },
  },
  // B01, 1 thread, w = 0, naive: where the time of a posted call goes (µs)
  postedSplit: { total: 112.9, scheduling: 25.6, waiting: 87.0 },
  // B01, 21 repetitions: x = naive, then futures with d = 0, 1, 2, 4, 8, 16
  futures: {
    x: ['naive', '0', '1', '2', '4', '8', '16'],
    t1: { 'w = 0': [112.9, 88.1, 47.4, 31.3, 19.8, 11.8, 8.7],
          'w = 10 µs': [106.2, 104.3, 59.4, 35.9, 24.2, 20.3, 19.6],
          'w = 50 µs': [173.3, 198.4, 73.1, 66.3, 64.7, 65.2, 64.1] },
    t4: { 'w = 0': [20.3, 20.1, 13.6, 10.7, 9.6, 8.5, 8.0],
          'w = 10 µs': [22.8, 24.9, 14.4, 12.2, 10.9, 10.0, 9.4],
          'w = 50 µs': [33.4, 31.7, 17.1, 16.8, 16.8, 16.8, 16.6] },
  },
  // B01 batching, 30 repetitions, medians: x = naive, then b = 1, 2, 4, 8, 16 calls per posted task (as far as the futures sweep)
  batching: {
    x: ['naive', '1', '2', '4', '8', '16'],
    t1: { 'w = 0': [120.1, 84.8, 49.6, 31.1, 22.1, 15.1],
          'w = 10 µs': [120.3, 110.8, 74.5, 52.5, 34.6, 25.2],
          'w = 50 µs': [211.0, 220.4, 133.3, 104.4, 79.9, 70.7] },
    t4: { 'w = 0': [21.5, 19.6, 10.9, 6.3, 4.3, 2.5],
          'w = 10 µs': [23.5, 22.9, 13.1, 8.7, 6.6, 5.4],
          'w = 50 µs': [31.8, 31.5, 23.1, 19.0, 16.9, 15.9] },
  },
  // B02, w = 0, groups of 16: [o, 1 thread naive, futures, 4 threads naive, futures]
  mixed: [[0, 2.8, 2.8, 2.4, 2.6], [0.25, 35.5, 7.1, 7.1, 4.0], [0.5, 63.6, 12.3, 11.3, 5.5],
          [0.75, 78.5, 14.1, 15.4, 6.7], [0.9, 90.0, 15.3, 19.1, 8.4], [1, 91.4, 16.6, 19.3, 9.0]],
  // B12 graph layout, 8 runs x 5 frames (first frame of each run skipped), one session: ms per frame,
  // [median, 95% interval low, high]. Optimised: coalesced accessors with packed values (mock of multi-value calls).
  graph: {
    N: [250, 500, 1000, 2000],
    'pure ArkTS': [[6.18, 5.83, 6.77], [18.66, 18.56, 18.80], [72.48, 72.30, 72.64], [285.27, 284.74, 286.08]],
    'naive': [[1.61, 1.40, 1.89], [3.63, 3.43, 4.31], [6.71, 6.26, 8.17], [16.24, 15.34, 16.68]],
    'optimised': [[1.02, 0.94, 1.17], [2.62, 2.30, 2.94], [4.80, 4.71, 5.17], [12.05, 11.96, 12.20]],
  },
  // B09 text-length sweep, 50 runs per cell in random order, one session. Speedup over pure ArkTS:
  // [ratio of medians, 95% interval low, high]. arkts: pure-ArkTS median, µs per item.
  breakeven: {
    L: [50, 100, 200, 500, 1000],
    arkts: [85.7, 124.1, 203.9, 451.1, 863.2],
    'naive, 1 thread': [[0.21, 0.21, 0.22], [0.31, 0.30, 0.32], [0.49, 0.47, 0.60], [0.99, 0.94, 1.03], [1.53, 1.44, 1.63]],
    'naive, 4 threads': [[1.13, 1.06, 1.21], [1.57, 1.52, 1.66], [2.47, 2.29, 2.62], [3.95, 3.74, 4.46], [5.70, 4.92, 6.58]],
    'optimised, 1 thread': [[2.54, 2.34, 2.86], [2.93, 2.75, 3.11], [3.72, 3.36, 4.15], [4.38, 4.06, 4.89], [4.50, 4.08, 5.21]],
    'optimised, 4 threads': [[3.97, 3.77, 4.35], [5.20, 4.86, 5.69], [7.60, 6.94, 8.39], [9.12, 8.24, 10.19], [10.43, 8.78, 13.56]],
  },
  // B09 with 200-character descriptions, 1,000 items, 100 runs in random order: µs per item, [median, 95% interval low, high].
  // Groups: naive, batching, futures, futures + batching; each [without, with] coalesce + scoped + cache.
  search: {
    arkts: 209.0,
    t1: [[[428.1, 411.7, 443.9], [410.2, 393.7, 416.9]],   // neither
         [[134.1, 125.5, 137.8], [123.6, 116.1, 128.1]],   // batching
         [[86.0, 82.3, 92.7], [87.6, 83.6, 96.3]],         // futures
         [[59.6, 56.1, 65.9], [57.5, 54.1, 61.4]]],        // futures + batching
    t4: [[[85.0, 81.9, 88.0], [87.8, 82.5, 91.3]],
         [[43.6, 40.4, 46.5], [37.2, 33.5, 38.8]],
         [[45.6, 42.8, 47.0], [39.7, 36.8, 41.9]],
         [[32.6, 30.3, 35.0], [28.3, 25.6, 31.4]]],
  },


  // B08, 32 repetitions (two runs pooled): µs per record; unique strings per 10,000 records
  cache: {
    u: ['1', '10', '100', '1,000', '10,000'],
    naive: [7.63, 7.03, 7.07, 7.73, 10.47],
    names: [6.08, 6.10, 6.21, 6.53, 7.91],
    namesValues: [4.36, 4.31, 4.35, 4.69, 8.45],
  },
  // B07, 25 repetitions: µs per element (objects) / per call (strings), including the ArkTS -> Cangjie call
  temps: {
    n: [10, 100, 1000, 10000],
    objects: { user: [4.36, 3.55, 3.42, 3.39], generated: [3.20, 2.21, 2.38, 2.43] },
    strings: { user: [4.02, 3.23, 3.06, 3.22], generated: [2.83, 1.87, 2.18, 2.25] },
  },
  // B03, µs per path read, depth d = 1, 2, 4, 8
  bunch: {
    d: [1, 2, 4, 8],
    'property reads': [0.64, 1.40, 2.36, 5.21],
    'property reads, keys created once': [0.48, 1.06, 1.79, 3.81],
    'one call per level': [0.88, 1.85, 3.43, 7.23],
    'one call per path': [0.88, 0.89, 0.83, 0.88],
  },
};

// ---------------------------------------------------------------------------
// Minimal SVG helpers. Plain colours for series identity, always with direct labels.
// ---------------------------------------------------------------------------
const NS = 'http://www.w3.org/2000/svg';
function el(parent, tag, attrs, text) {
  const e = document.createElementNS(NS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (text !== undefined) e.textContent = text;
  parent.appendChild(e);
  return e;
}
const STYLES = [
  { stroke: '#2a78d6', dash: '' },  // blue
  { stroke: '#eb6834', dash: '' },  // orange
  { stroke: '#1baf7a', dash: '' },  // green
  { stroke: '#eda100', dash: '' },  // yellow
];
const TIER_COLOUR = { arkts: '#777', direct: '#2a78d6', posted: '#2a78d6' };
function niceMax(v) {
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 2, 2.5, 4, 5, 8, 10]) if (m * p >= v) return m * p;
  return 10 * p;
}
function fmt(v) { return v < 0.1 ? v.toFixed(3) : v < 10 ? v.toFixed(2) : v.toFixed(1); }

// Line chart. xs: category labels or numbers (numeric: true). series: {name: [values]}.
function lineChart(svg, { xs, series, title, xlabel, ylabel, numeric, ymax, labelDy, right, refLine, labelAtStart, reverseX, ticks, ci }) {
  const W = +svg.getAttribute('width'), H = +svg.getAttribute('height');
  const m = { l: 48, r: right || 110, t: 30, b: 44 };
  const iw = W - m.l - m.r, ih = H - m.t - m.b;
  const names = Object.keys(series);
  const top = ymax || niceMax(Math.max(...names.flatMap(n => series[n])));
  const xmax = numeric ? Math.max(...xs) : xs.length - 1;
  const frac = (i) => numeric ? xs[i] / xmax : i / (xs.length - 1);
  const X = (i) => m.l + (reverseX ? 1 - frac(i) : frac(i)) * iw;
  const Y = (v) => m.t + ih - (v / top) * ih;
  if (title) el(svg, 'text', { x: 0, y: 16, 'font-size': 14, 'font-weight': 600 }, title);
  const nt = ticks || 4;
  for (let k = 0; k <= nt; k++) {
    const v = top * k / nt, y = Y(v);
    el(svg, 'line', { x1: m.l, x2: m.l + iw, y1: y, y2: y, class: k === 0 ? 'base' : 'grid' });
    el(svg, 'text', { x: m.l - 8, y: y + 4, 'font-size': 11.5, 'text-anchor': 'end', class: 'tick' }, String(+v.toFixed(2)));
  }
  if (refLine !== undefined) {
    el(svg, 'line', { x1: m.l, x2: m.l + iw, y1: Y(refLine), y2: Y(refLine), class: 'ref' });
    el(svg, 'text', { x: m.l + iw + 6, y: Y(refLine) + 4, 'font-size': 11.5, class: 'tick' }, `${refLine}×`);
  }
  xs.forEach((x, i) => el(svg, 'text', { x: X(i), y: m.t + ih + 18, 'font-size': 11.5, 'text-anchor': 'middle', class: 'tick' }, String(x)));
  if (xlabel) el(svg, 'text', { x: m.l + iw / 2, y: H - 4, 'font-size': 12.5, 'text-anchor': 'middle', class: 'axlabel' }, xlabel);
  if (ylabel) el(svg, 'text', { x: 12, y: m.t + ih / 2, 'font-size': 12.5, 'text-anchor': 'middle', class: 'axlabel',
                                transform: `rotate(-90 12 ${m.t + ih / 2})` }, ylabel);
  // direct labels, nudged apart if too close
  const ends = names.map((n) => ({ n, y: Y(series[n][labelAtStart ? 0 : series[n].length - 1]) }));
  ends.sort((a, b) => a.y - b.y);
  for (let i = 1; i < ends.length; i++) if (ends[i].y - ends[i - 1].y < 16) ends[i].y = ends[i - 1].y + 16;
  // interval bars (95%), drawn under the lines; clipped to the plot
  if (ci) names.forEach((n, s) => (ci[n] || []).forEach(([a, b], i) => {
    const y1 = Y(Math.min(b, top)), y2 = Y(Math.max(a, 0)), x = X(i), c = STYLES[s].stroke;
    el(svg, 'line', { x1: x, x2: x, y1: y1, y2: y2, stroke: c, 'stroke-width': 1.5, opacity: 0.6 });
    if (b <= top) el(svg, 'line', { x1: x - 3, x2: x + 3, y1: y1, y2: y1, stroke: c, 'stroke-width': 1.5, opacity: 0.6 });
    el(svg, 'line', { x1: x - 3, x2: x + 3, y1: y2, y2: y2, stroke: c, 'stroke-width': 1.5, opacity: 0.6 });
  }));
  names.forEach((n, s) => {
    const st = STYLES[s], ys = series[n];
    el(svg, 'polyline', { points: ys.map((v, i) => `${X(i)},${Y(v)}`).join(' '), fill: 'none', stroke: st.stroke,
                          'stroke-width': 2.5, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' });
    ys.forEach((v, i) => {
      const c = el(svg, 'circle', { cx: X(i), cy: Y(v), r: 4.5, fill: st.stroke, stroke: '#fff', 'stroke-width': 1.5 });
      el(c, 'title', {}, `${n}, ${xs[i]}: ${fmt(v)}`);
    });
    const e = ends.find(e => e.n === n);
    const lx = labelAtStart ? m.l + 10 : m.l + iw + 10;
    const ly = labelAtStart ? e.y - 16 : e.y + 4 + (labelDy || 0);
    el(svg, 'rect', { x: lx, y: ly - 8, width: 8, height: 3, rx: 1.5, fill: st.stroke });
    el(svg, 'text', { x: lx + 13, y: ly, 'font-size': 12.5, 'font-weight': 500 }, n);
  });
}

// Table from a header row and data rows (numbers right-aligned); optional group header row [[label, span], ...].
function table(id, head, rows, groups) {
  const t = document.getElementById(id);
  const cell = (v, tag) => `<${tag}${typeof v === 'number' || /^[−0-9.,×%]+$/.test(v) ? ' class="n"' : ''}>${v}</${tag}>`;
  const top = groups ? '<tr class="grp">' + groups.map(([g, n]) => `<th colspan="${n}">${g ? `<span>${g}</span>` : ''}</th>`).join('') + '</tr>' : '';
  t.innerHTML = top + '<tr>' + head.map(h => cell(h, 'th')).join('') + '</tr>' +
    rows.map(r => '<tr>' + r.map(v => cell(v, 'td')).join('') + '</tr>').join('');
}
const x1 = (a, b) => (a / b).toFixed(1) + '×';

// Breakdown of the posted call: a stacked bar on its own linear scale (0 .. total), linked to the posted point.
function postedSplitBar(svg, sp, px, py, m, iw, W) {
  const y0 = m.t + (+svg.getAttribute('height') - m.t - m.b) + 58, h = 26;
  const x0 = m.l, x1 = m.l + iw;
  const xs = x0 + (x1 - x0) * sp.scheduling / sp.total;
  // zoom lines from the posted point to both ends of the bar
  [x0, x1].forEach(x => el(svg, 'line', { x1: px, y1: py + 8, x2: x, y2: y0 - 2, stroke: '#b3b8bf', 'stroke-width': 1, 'stroke-dasharray': '3 3' }));
  el(svg, 'rect', { x: x0, y: y0, width: xs - x0 - 1, height: h, rx: 3, fill: '#9cc0ee' });
  el(svg, 'rect', { x: xs + 1, y: y0, width: x1 - xs - 1, height: h, rx: 3, fill: '#2a78d6' });
  el(svg, 'text', { x: x0 + 8, y: y0 + 17.5, 'font-size': 13 }, sp.scheduling.toFixed(1));
  el(svg, 'text', { x: x0, y: y0 + h + 18, 'font-size': 13 }, 'posting, incl. waking the ArkTS thread');
  el(svg, 'text', { x: xs + 10, y: y0 + 17.5, 'font-size': 13, style: 'fill: #fff' }, `waiting for the result ${sp.waiting.toFixed(1)}`);
  el(svg, 'text', { x: m.l - 14, y: y0 + 17.5, 'font-size': 14.5, 'text-anchor': 'end' }, 'of which (µs, linear)');
}

// Horizontal dot plot on a log axis. Direct rows: ArkTS and Cangjie points joined by a line.
function logDots(svg, rows, split) {
  const W = +svg.getAttribute('width'), H = +svg.getAttribute('height');
  const m = { l: 300, r: 110, t: 40, b: 128 };
  const iw = W - m.l - m.r, ih = H - m.t - m.b;
  const lo = -3, hi = 3; // 0.001 .. 1000 µs
  const X = (v) => m.l + (Math.log10(v) - lo) / (hi - lo) * iw;
  const rowH = ih / rows.length;
  rows.forEach((r, i) => {
    if (i % 2 === 0) el(svg, 'rect', { x: 0, y: m.t + rowH * i, width: W - m.r + 60, height: rowH, fill: '#f7f8fa' });
  });
  for (let e = lo; e <= hi; e++) {
    const x = X(Math.pow(10, e));
    el(svg, 'line', { x1: x, x2: x, y1: m.t, y2: m.t + ih, class: 'grid' });
    el(svg, 'text', { x, y: m.t + ih + 18, 'font-size': 11.5, 'text-anchor': 'middle', class: 'tick' }, String(Math.pow(10, e)));
  }
  el(svg, 'text', { x: m.l + iw / 2, y: m.t + ih + 34, 'font-size': 12.5, 'text-anchor': 'middle', class: 'axlabel' }, 'µs per operation (log scale)');
  // legend
  [['ArkTS', TIER_COLOUR.arkts], ['Cangjie interop', TIER_COLOUR.direct]]
    .forEach(([name, c], i) => {
      const x = m.l + i * 170;
      el(svg, 'circle', { cx: x + 6, cy: 14, r: 6, fill: c });
      el(svg, 'text', { x: x + 18, y: 19, 'font-size': 13.5 }, name);
    });
  rows.forEach((r, i) => {
    const y = m.t + rowH * (i + 0.5);
    const summary = r.label.startsWith('Average') || r.posted !== undefined;
    if (summary && !(i > 0 && (rows[i - 1].label.startsWith('Average')))) {
      el(svg, 'line', { x1: 0, x2: W - m.r + 60, y1: m.t + rowH * i, y2: m.t + rowH * i, stroke: '#c9ced6', 'stroke-width': 1 });
    }
    el(svg, 'text', { x: m.l - 14, y: y + 5, 'font-size': 14.5, 'text-anchor': 'end',
                      'font-weight': r.label.startsWith('Average') ? 600 : 400 }, r.label);
    if (r.posted !== undefined) {
      el(svg, 'circle', { cx: X(r.posted), cy: y, r: 7, fill: TIER_COLOUR.posted, stroke: '#fff', 'stroke-width': 2 });
      el(svg, 'text', { x: X(r.posted) + 13, y: y + 5, 'font-size': 14 }, String(r.posted));
      if (split) postedSplitBar(svg, split, X(r.posted), y, m, iw, W);
      return;
    }
    el(svg, 'line', { x1: X(r.arkts), x2: X(r.cj), y1: y, y2: y, stroke: '#d3d8df', 'stroke-width': 3, 'stroke-linecap': 'round' });
    el(svg, 'circle', { cx: X(r.arkts), cy: y, r: 7, fill: TIER_COLOUR.arkts, stroke: '#fff', 'stroke-width': 2 });
    el(svg, 'text', { x: X(r.arkts) - 13, y: y + 5, 'font-size': 13.5, 'text-anchor': 'end', class: 'tick' }, String(r.arkts));
    el(svg, 'circle', { cx: X(r.cj), cy: y, r: 7, fill: TIER_COLOUR.direct, stroke: '#fff', 'stroke-width': 2 });
    const t = el(svg, 'text', { x: X(r.cj) + 13, y: y + 5, 'font-size': 14 }, `${r.cj}`);
    const tt = document.createElementNS(NS, 'tspan');
    tt.setAttribute('class', 'tick');
    tt.textContent = `  ${Math.round(r.cj / r.arkts)}× ArkTS`;
    t.appendChild(tt);
  });
}

// ---------------------------------------------------------------------------
const directRows = DATA.tiers.filter(r => r.posted === undefined);
const mean = (xs) => xs.reduce((a, b) => a + b, 0) / xs.length;
const avgRow = { label: 'Average of the above', arkts: +mean(directRows.map(r => r.arkts)).toFixed(3),
                 cj: +mean(directRows.map(r => r.cj)).toFixed(2) };
logDots(document.getElementById('fig-tiers'), [...directRows, avgRow, ...DATA.tiers.filter(r => r.posted !== undefined)], DATA.postedSplit);
lineChart(document.getElementById('fig-fut1'), { xs: DATA.futures.x, series: DATA.futures.t1, ci: DATA.ci.fut1,
  title: '1 thread: µs per call', xlabel: 'calls in flight d' });
lineChart(document.getElementById('fig-fut4'), { xs: DATA.futures.x, series: DATA.futures.t4, ci: DATA.ci.fut4,
  title: '4 threads: µs per call', xlabel: 'calls in flight d' });
// main thread work = % of calls made on the ArkTS thread = (1 - o) * 100, from 100% down to 0%
const mixRows = DATA.mixed.map(r => [Math.round((1 - r[0]) * 100), ...r.slice(1)]).sort((p, q) => q[0] - p[0]);
const seq = mixRows.map(r => r[0]);
lineChart(document.getElementById('fig-mix'), { xs: seq, numeric: true, ymax: 9, ticks: 3, refLine: 1, reverseX: true, ci: DATA.ci.mix,
  series: { '1 thread': mixRows.map(r => r[1] / r[2]), '4 threads': mixRows.map(r => r[3] / r[4]) },
  title: 'speedup of futures over naive (×)', xlabel: 'main thread work (%)' });
table('tab-mix', ['main thread', 'naive µs', 'futures µs', 'speedup', 'naive µs', 'futures µs', 'speedup'],
  mixRows.map(r => [r[0] + '%', r[1].toFixed(1), r[2].toFixed(1), x1(r[1], r[2]), r[3].toFixed(1), r[4].toFixed(1), x1(r[3], r[4])]),
  [['', 1], ['1 thread', 3], ['4 threads', 3]]);
table('tab-fut', ['threads', 'w µs', 'naive µs', 'd = 4 µs', 'd = 16 µs', 'speedup (d = 16)'],
  [['1', DATA.futures.t1], ['4', DATA.futures.t4]].flatMap(([t, ser]) =>
    Object.keys(ser).map(w => [t, w.replace('w = ', '').replace(' µs', ''), ser[w][0].toFixed(1), ser[w][4].toFixed(1),
      ser[w][6].toFixed(1), x1(ser[w][0], ser[w][6])])));
lineChart(document.getElementById('fig-bat1'), { xs: DATA.batching.x, ymax: 250, ticks: 5, series: DATA.batching.t1, ci: DATA.ci.bat1,
  title: '1 thread: µs per call', xlabel: 'calls per task b' });
lineChart(document.getElementById('fig-bat4'), { xs: DATA.batching.x, series: DATA.batching.t4, ci: DATA.ci.bat4,
  title: '4 threads: µs per call', xlabel: 'calls per task b' });
table('tab-bat', ['threads', 'w µs', 'naive µs', 'b = 4 µs', 'b = 16 µs', 'speedup (b = 16)'],
  [['1', DATA.batching.t1], ['4', DATA.batching.t4]].flatMap(([t, ser]) =>
    Object.keys(ser).map(w => [t, w.replace('w = ', '').replace(' µs', ''), ser[w][0].toFixed(1), ser[w][3].toFixed(1),
      ser[w][5].toFixed(1), x1(ser[w][0], ser[w][5])])));
lineChart(document.getElementById('fig-bunch'), { xs: DATA.bunch.d, numeric: true, ymax: 6, ticks: 3, ci: DATA.ci.bunch,
  series: { 'naive': DATA.bunch['property reads'], 'coalesced': DATA.bunch['one call per path'] },
  title: 'µs per path read', xlabel: 'depth d' });
table('tab-bunch', ['depth d', 'naive µs', 'coalesced µs', 'speedup'],
  DATA.bunch.d.map((d, i) => [d, DATA.bunch['property reads'][i].toFixed(2), DATA.bunch['one call per path'][i].toFixed(2),
    x1(DATA.bunch['property reads'][i], DATA.bunch['one call per path'][i])]));

// 2 x 2 grid of small dot plots: rows futures off / on, columns batching off / on. Each cell: two rows,
// as is (grey) and + coalesce, scoped, cache (blue). One x axis for the whole panel; pure ArkTS as a dashed line.
function gridDots(svg, groups, arkts, title, top, step) {
  const W = +svg.getAttribute('width');
  const left = 78, gap = 30, colW = (W - left - gap - 26) / 2, rowH = 44, cellH = 2 * rowH + 16, headH = 46;
  const colours = ['#8a8f98', '#2a78d6'];
  const names = ['as is', '+ coalesce, scoped, cache'];
  el(svg, 'text', { x: 0, y: 16, 'font-size': 14, 'font-weight': 600 }, title);
  ['batching off', 'batching on'].forEach((c, j) =>
    el(svg, 'text', { x: left + j * (colW + gap) + colW / 2, y: headH - 10, 'font-size': 13, 'font-weight': 600,
                      'text-anchor': 'middle' }, c));
  for (let f = 0; f < 2; f++) {
    const y0 = headH + f * (cellH + gap);
    el(svg, 'text', { x: 0, y: y0 + cellH / 2 - 3, 'font-size': 13, 'font-weight': 600 }, 'futures');
    el(svg, 'text', { x: 0, y: y0 + cellH / 2 + 13, 'font-size': 13, 'font-weight': 600 }, f ? 'on' : 'off');
    for (let b = 0; b < 2; b++) {
      const x0 = left + b * (colW + gap);
      const X = (v) => x0 + (v / top) * colW;
      el(svg, 'rect', { x: x0, y: y0, width: colW, height: cellH, fill: '#fafbfc', stroke: '#dcdfe3', rx: 4 });
      for (let v = step; v < top; v += step) {
        el(svg, 'line', { x1: X(v), x2: X(v), y1: y0 + 1, y2: y0 + cellH - 1, class: 'grid' });
      }
      el(svg, 'line', { x1: X(arkts), x2: X(arkts), y1: y0 + 1, y2: y0 + cellH - 1, class: 'ref' });
      if (f === 0) el(svg, 'text', { x: X(arkts) - 4, y: y0 + 13, 'font-size': 11, 'text-anchor': 'end', class: 'tick' }, `pure ArkTS ${arkts.toFixed(0)}`);
      groups[f * 2 + b].forEach(([med, lo, hi], k) => {
        const cy = y0 + 8 + rowH * k + rowH / 2 + 4;
        el(svg, 'line', { x1: X(lo), x2: X(hi), y1: cy, y2: cy, stroke: colours[k], 'stroke-width': 3, 'stroke-linecap': 'round' });
        const c = el(svg, 'line', { x1: X(med), x2: X(med), y1: cy - 8, y2: cy + 8, stroke: colours[k], 'stroke-width': 2.5,
                                    'stroke-linecap': 'round' });
        el(c, 'title', {}, `futures ${f ? 'on' : 'off'}, batching ${b ? 'on' : 'off'}, ${names[k]}: ` +
                           `${med.toFixed(1)} µs [${lo.toFixed(1)}, ${hi.toFixed(1)}]`);
        el(svg, 'text', { x: X(hi) + 7, y: cy + 4.5, 'font-size': 13, class: 'tick' }, med.toFixed(0));
      });
      if (f === 1) {
        for (let v = 0; v <= top; v += step) {
          el(svg, 'text', { x: X(v), y: y0 + cellH + 15, 'font-size': 11, 'text-anchor': 'middle', class: 'tick' }, String(v));
        }
        el(svg, 'text', { x: x0 + colW / 2, y: y0 + cellH + 32, 'font-size': 12, 'text-anchor': 'middle', class: 'axlabel' }, 'µs per item');
      }
    }
  }
}
gridDots(document.getElementById('fig-search1'), DATA.search.t1, DATA.search.arkts, '1 thread', 500, 100);
gridDots(document.getElementById('fig-search4'), DATA.search.t4, DATA.search.arkts, '4 threads', 250, 50);

// Speedup over pure ArkTS against description length: log y axis, 1x reference, interval bars, direct labels.
function evenChart(svg, D) {
  const W = +svg.getAttribute('width'), H = +svg.getAttribute('height');
  const m = { l: 48, r: 150, t: 30, b: 44 };
  const iw = W - m.l - m.r, ih = H - m.t - m.b;
  const lo = 0.2, hi = 20;
  const X = (i) => m.l + (i / (D.L.length - 1)) * iw;
  const Y = (v) => m.t + ih - (Math.log(v / lo) / Math.log(hi / lo)) * ih;
  el(svg, 'text', { x: 0, y: 16, 'font-size': 14, 'font-weight': 600 }, 'speedup over pure ArkTS (×, log scale)');
  [0.2, 0.5, 1, 2, 5, 10, 20].forEach(v => {
    el(svg, 'line', { x1: m.l, x2: m.l + iw, y1: Y(v), y2: Y(v), class: v === 1 ? 'ref' : 'grid' });
    el(svg, 'text', { x: m.l - 8, y: Y(v) + 4, 'font-size': 11.5, 'text-anchor': 'end', class: 'tick' }, String(v));
  });
  el(svg, 'text', { x: m.l + iw + 10, y: Y(1) + 4, 'font-size': 12, class: 'tick' }, '1× = as fast as ArkTS');
  D.L.forEach((L, i) => el(svg, 'text', { x: X(i), y: m.t + ih + 18, 'font-size': 11.5, 'text-anchor': 'middle', class: 'tick' }, String(L)));
  el(svg, 'text', { x: m.l + iw / 2, y: H - 4, 'font-size': 12.5, 'text-anchor': 'middle', class: 'axlabel' }, 'text length per item, L (characters)');
  const series = [['optimised, 4 threads', '#2a78d6', ''], ['optimised, 1 thread', '#2a78d6', '6 4'],
                  ['naive, 4 threads', '#eb6834', ''], ['naive, 1 thread', '#eb6834', '6 4']];
  const ends = series.map(([n]) => ({ n, y: Y(D[n][D[n].length - 1][0]) })).sort((a, b) => a.y - b.y);
  for (let i = 1; i < ends.length; i++) if (ends[i].y - ends[i - 1].y < 16) ends[i].y = ends[i - 1].y + 16;
  series.forEach(([n, colour, dash]) => {
    const pts = D[n];
    el(svg, 'polyline', { points: pts.map((p, i) => `${X(i)},${Y(p[0])}`).join(' '), fill: 'none', stroke: colour,
                          'stroke-width': 2.5, 'stroke-dasharray': dash, 'stroke-linejoin': 'round' });
    pts.forEach(([v, a, b], i) => {
      el(svg, 'line', { x1: X(i), x2: X(i), y1: Y(a), y2: Y(b), stroke: colour, 'stroke-width': 1.5 });
      const c = el(svg, 'circle', { cx: X(i), cy: Y(v), r: 4, fill: colour, stroke: '#fff', 'stroke-width': 1.5 });
      el(c, 'title', {}, `${n}, L = ${D.L[i]}: ${v.toFixed(2)}× [${a.toFixed(2)}, ${b.toFixed(2)}]`);
    });
    const e = ends.find(e => e.n === n);
    el(svg, 'line', { x1: m.l + iw + 10, x2: m.l + iw + 22, y1: e.y, y2: e.y, stroke: colour, 'stroke-width': 2.5, 'stroke-dasharray': dash ? '4 2' : '' });
    el(svg, 'text', { x: m.l + iw + 27, y: e.y + 4, 'font-size': 12.5, 'font-weight': 500 }, n);
  });
}
evenChart(document.getElementById('fig-even'), DATA.breakeven);

// Graph layout: ms per frame against N, log y, frame budget line, interval bars, direct labels.
function graphChart(svg, D) {
  const W = +svg.getAttribute('width'), H = +svg.getAttribute('height');
  const m = { l: 48, r: 120, t: 30, b: 44 };
  const iw = W - m.l - m.r, ih = H - m.t - m.b;
  const lo = 1, hi = 500;
  const X = (i) => m.l + (i / (D.N.length - 1)) * iw;
  const Y = (v) => m.t + ih - (Math.log(v / lo) / Math.log(hi / lo)) * ih;
  el(svg, 'text', { x: 0, y: 16, 'font-size': 14, 'font-weight': 600 }, 'ms per frame (log scale)');
  [1, 2, 5, 10, 20, 50, 100, 200, 500].forEach(v => {
    el(svg, 'line', { x1: m.l, x2: m.l + iw, y1: Y(v), y2: Y(v), class: 'grid' });
    el(svg, 'text', { x: m.l - 8, y: Y(v) + 4, 'font-size': 11.5, 'text-anchor': 'end', class: 'tick' }, String(v));
  });
  el(svg, 'line', { x1: m.l, x2: m.l + iw, y1: Y(16.6), y2: Y(16.6), class: 'ref' });
  el(svg, 'text', { x: m.l + 6, y: Y(16.6) - 6, 'font-size': 11.5, class: 'tick' }, '16.6 ms = 60 fps');
  D.N.forEach((n, i) => el(svg, 'text', { x: X(i), y: m.t + ih + 18, 'font-size': 11.5, 'text-anchor': 'middle', class: 'tick' }, n.toLocaleString('en-US')));
  el(svg, 'text', { x: m.l + iw / 2, y: H - 4, 'font-size': 12.5, 'text-anchor': 'middle', class: 'axlabel' }, 'nodes N');
  const series = [['pure ArkTS', '#8a8f98'], ['naive', '#eb6834'], ['optimised', '#2a78d6']];
  const ends = series.map(([n]) => ({ n, y: Y(D[n][D[n].length - 1][0]) })).sort((a, b) => a.y - b.y);
  for (let i = 1; i < ends.length; i++) if (ends[i].y - ends[i - 1].y < 16) ends[i].y = ends[i - 1].y + 16;
  series.forEach(([n, colour]) => {
    const pts = D[n];
    el(svg, 'polyline', { points: pts.map((p, i) => `${X(i)},${Y(p[0])}`).join(' '), fill: 'none', stroke: colour,
                          'stroke-width': 2.5, 'stroke-linejoin': 'round' });
    pts.forEach(([v, a, b], i) => {
      el(svg, 'line', { x1: X(i), x2: X(i), y1: Y(a), y2: Y(b), stroke: colour, 'stroke-width': 1.5, opacity: 0.6 });
      const c = el(svg, 'circle', { cx: X(i), cy: Y(v), r: 4, fill: colour, stroke: '#fff', 'stroke-width': 1.5 });
      el(c, 'title', {}, `${n}, N = ${D.N[i]}: ${v.toFixed(2)} ms [${a.toFixed(2)}, ${b.toFixed(2)}]`);
    });
    const e = ends.find(e => e.n === n);
    el(svg, 'line', { x1: m.l + iw + 10, x2: m.l + iw + 22, y1: e.y, y2: e.y, stroke: colour, 'stroke-width': 2.5 });
    el(svg, 'text', { x: m.l + iw + 27, y: e.y + 4, 'font-size': 12.5, 'font-weight': 500 }, n);
  });
}
graphChart(document.getElementById('fig-graph'), DATA.graph);

table('tab-graph', ['nodes N', 'naive ms', 'optimised ms', 'vs naive', 'pure ArkTS ms'],
  DATA.graph.N.map((n, i) => {
    const nv = DATA.graph.naive[i][0], op = DATA.graph.optimised[i][0];
    return [n.toLocaleString('en-US'), nv.toFixed(2), op.toFixed(2), `−${(100 * (1 - op / nv)).toFixed(0)}%`,
      DATA.graph['pure ArkTS'][i][0].toFixed(1)];
  }));
{
  const D = DATA.breakeven, f = (p) => `${p[0].toFixed(2)}×`;
  table('tab-even', ['L', 'ArkTS µs', '1 thread', '4 threads', '1 thread', '4 threads'],
    D.L.map((L, i) => [String(L), D.arkts[i].toFixed(1), f(D['naive, 1 thread'][i]), f(D['naive, 4 threads'][i]),
                       f(D['optimised, 1 thread'][i]), f(D['optimised, 4 threads'][i])]),
    [['', 2], ['naive', 2], ['optimised', 2]]);
}

const C = DATA.cache;
lineChart(document.getElementById('fig-cache'), { xs: C.u, ymax: 2.5, ticks: 5, refLine: 1, right: 170, ci: DATA.ci.cache,
  series: { 'names + values cached': C.u.map((_, i) => C.naive[i] / C.namesValues[i]),
            'names cached': C.u.map((_, i) => C.naive[i] / C.names[i]) },
  title: 'speedup over naive (×)', xlabel: 'unique strings (per 10,000 records)' });
table('tab-cache', ['unique strings', 'naive', 'names', 'names + values', 'names', 'names + values'],
  C.u.map((u, i) => [u, C.naive[i].toFixed(2), C.names[i].toFixed(2), C.namesValues[i].toFixed(2),
    x1(C.naive[i], C.names[i]), x1(C.naive[i], C.namesValues[i])]),
  [['', 1], ['µs per record', 3], ['speedup over naive', 2]]);

const T = DATA.temps;
lineChart(document.getElementById('fig-temp'), { xs: T.n.map(n => n.toLocaleString('en-US')), ymax: 2, ticks: 4, refLine: 1, ci: DATA.ci.temp,
  series: { optimised: T.n.map((_, i) => (T.objects.user[i] + T.strings.user[i]) / (T.objects.generated[i] + T.strings.generated[i])) },
  title: 'speedup of optimised over naive (×)', xlabel: 'N' });
table('tab-temp', ['N', 'naive µs', 'optimised µs', 'speedup'],
  T.n.map((n, i) => {
    const nv = T.objects.user[i] + T.strings.user[i], op = T.objects.generated[i] + T.strings.generated[i];
    return [n.toLocaleString('en-US'), nv.toFixed(2), op.toFixed(2), x1(nv, op)];
  }));

// ---------------------------------------------------------------------------
// Minimal syntax highlighting (Cangjie / ArkTS): comments, strings, keywords, numbers.
// ---------------------------------------------------------------------------
const KEYWORDS = 'func|let|var|for|in|if|else|return|const|match|case|while|true|false|None|Some|class|init|repeat';
const TOKEN = new RegExp(`(//[^\\n]*)|("(?:[^"\\\\]|\\\\.)*")|\\b(${KEYWORDS})\\b|\\b(\\d+(?:\\.\\d+)?)\\b`, 'g');
function highlight(pre) {
  const esc = (t) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  // marks: «…» = redundant (naive), ‹…› = optimised; removed from the text, kept as a per-character class
  const raw = pre.textContent;
  let src = '';
  const mark = [];
  let cur = '';
  for (const ch of raw) {
    if (ch === '«') { cur = 'mk-bad'; continue; }
    if (ch === '‹') { cur = 'mk-good'; continue; }
    if (ch === '»' || ch === '›') { cur = ''; continue; }
    for (let k = 0; k < ch.length; k++) mark.push(cur);
    src += ch;
  }
  const tok = new Array(src.length).fill('');
  let m;
  TOKEN.lastIndex = 0;
  while ((m = TOKEN.exec(src)) !== null) {
    const cls = m[1] ? 'tk-c' : m[2] ? 'tk-s' : m[3] ? 'tk-k' : 'tk-n';
    for (let k = m.index; k < m.index + m[0].length; k++) tok[k] = cls;
  }
  let out = '', i = 0;
  while (i < src.length) {
    let j = i;
    while (j < src.length && tok[j] === tok[i] && mark[j] === mark[i]) j++;
    const cls = [tok[i], mark[i]].filter(Boolean).join(' ');
    const text = esc(src.slice(i, j));
    out += cls ? `<span class="${cls}">${text}</span>` : text;
    i = j;
  }
  pre.innerHTML = out;
}
document.querySelectorAll('pre').forEach(highlight);

// Graph / table tabs on the optimisation slides: the table moves from the right column into the left one,
// behind a tab. Click a tab, or press "t" to toggle on the current slide.
document.querySelectorAll('.opt').forEach(opt => {
  const left = opt.querySelector('.opt-left'), right = opt.querySelector('.opt-right');
  const tables = [...right.querySelectorAll(':scope > table')];
  if (!tables.length || !right.querySelector('.split')) return;
  const graph = document.createElement('div'); graph.className = 'tabpane';
  while (left.firstChild) graph.appendChild(left.firstChild);
  const tab = document.createElement('div'); tab.className = 'tabpane'; tab.hidden = true;
  tables.forEach(t => tab.appendChild(t));
  const bar = document.createElement('div'); bar.className = 'tabs';
  const bg = document.createElement('button'), bt = document.createElement('button');
  bg.textContent = 'graph'; bt.textContent = 'table'; bg.className = 'on';
  const pick = (showTable) => { graph.hidden = showTable; tab.hidden = !showTable;
                                bg.classList.toggle('on', !showTable); bt.classList.toggle('on', showTable); };
  bg.onclick = () => pick(false); bt.onclick = () => pick(true);
  opt.toggleTab = () => pick(tab.hidden);   // show the table if it is hidden, else the graph
  bar.append(bg, bt); left.append(bar, graph, tab);
});
document.addEventListener('keydown', (e) => {
  if (e.key !== 't') return;
  const opt = document.querySelector('.slide.active .opt');
  if (opt && opt.toggleTab) opt.toggleTab();
});

// ---------------------------------------------------------------------------
// Navigation: arrows / PageUp / PageDown / Home / End; slide number in the URL hash.
// ---------------------------------------------------------------------------
const slides = [...document.querySelectorAll('.slide')];
slides.forEach((s, i) => {
  const n = document.createElement('div');
  n.className = 'num';
  n.textContent = `${i + 1} / ${slides.length}`;
  s.appendChild(n);
});
let cur = Math.min(Math.max((parseInt(location.hash.slice(1)) || 1) - 1, 0), slides.length - 1);
window.addEventListener('hashchange', () => { const n = parseInt(location.hash.slice(1)); if (n && n - 1 !== cur) show(n - 1); });
function show(i) {
  cur = Math.min(Math.max(i, 0), slides.length - 1);
  slides.forEach((s, k) => s.classList.toggle('active', k === cur));
  document.querySelectorAll('details.code').forEach(d => d.open = false);
  history.replaceState(null, '', '#' + (cur + 1));
  fit();
}
function fit() {
  const s = Math.min(window.innerWidth / 1280, window.innerHeight / 720);
  slides.forEach(x => x.style.transform = `scale(${s})`);
}
document.addEventListener('keydown', (e) => {
  if (['ArrowRight', 'PageDown', ' '].includes(e.key)) show(cur + 1);
  else if (['ArrowLeft', 'PageUp'].includes(e.key)) show(cur - 1);
  else if (e.key === 'Home') show(0);
  else if (e.key === 'End') show(slides.length - 1);
});
window.addEventListener('resize', fit);
show(cur);
