#!/usr/bin/env python3
"""Summarize a selected benchmark table from app CSV files or hilog captures."""

import argparse
from collections import defaultdict
import csv
import math
from pathlib import Path
import statistics
import sys


def read_records(path, benchmark, metric, groups, drop_first_frame):
    header = None
    records = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if "BENCH_ERROR," in line:
            error = line.split("BENCH_ERROR,", 1)[1]
            if error.split(",", 1)[0] == benchmark:
                raise ValueError(f"{path}:{line_number}: benchmark reported an exception")
            continue
        text = line.split("BENCH,", 1)[1] if "BENCH," in line else line
        try:
            row = next(csv.reader([text], strict=True))
        except csv.Error as error:
            raise ValueError(f"{path}:{line_number}: malformed CSV") from error
        if not row or row[0] != benchmark:
            continue
        values = row[1:]
        if metric in values and "rep" in values:
            if len(set(values)) != len(values):
                raise ValueError(f"{path}:{line_number}: duplicate header fields")
            header = values
            required = {metric, "rep", *groups}
            if drop_first_frame:
                required.add("frame")
            missing = required - set(header)
            if missing:
                raise ValueError(f"{path}:{line_number}: missing columns: {', '.join(sorted(missing))}")
            continue
        if header is None:
            raise ValueError(f"{path}:{line_number}: selected data appeared before its metric header")
        if len(values) != len(header):
            raise ValueError(f"{path}:{line_number}: expected {len(header)} fields, got {len(values)}")
        record = dict(zip(header, values))
        for field, expected in (("ok", 1), ("errors", 0)):
            if field in record and float(record[field]) != expected:
                raise ValueError(f"{path}:{line_number}: failed correctness indicator {field}={record[field]}")
        value = float(record[metric])
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"{path}:{line_number}: invalid timing value")
        if drop_first_frame and int(record["frame"]) == 0:
            continue
        records.append(record)
    return records


def summarize(paths, benchmark, metric, groups, drop_first_frame=False):
    runs = defaultdict(list)
    for path in paths:
        for record in read_records(path, benchmark, metric, groups, drop_first_frame):
            group = tuple(record[field] for field in groups)
            runs[(str(path.resolve()), group, record["rep"])].append(float(record[metric]))
    grouped = defaultdict(list)
    row_counts = defaultdict(int)
    for (source, group, rep), values in runs.items():
        grouped[group].append(statistics.median(values))
        row_counts[group] += len(values)
    if not grouped:
        raise ValueError("No matching measurements found")
    return [
        list(group) + [len(values), row_counts[group], statistics.median(values), min(values), max(values)]
        for group, values in sorted(grouped.items())
    ]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("files", nargs="+", type=Path)
    parser.add_argument("--benchmark", required=True, help="table identifier, for example b03 or b09b")
    parser.add_argument("--metric", required=True, help="timing column, for example ns_per_path")
    parser.add_argument("--group-by", required=True, help="comma-separated workload and variant columns")
    parser.add_argument("--drop-first-frame", action="store_true", help="exclude frame 0, requires a frame column")
    args = parser.parse_args()
    groups = [field.strip() for field in args.group_by.split(",")]
    if any(not field for field in groups) or len(set(groups)) != len(groups):
        parser.error("--group-by must contain distinct nonempty field names")
    if {"rep", "frame"} & set(groups):
        parser.error("group by workload and variant fields; rep and frame are handled as samples")
    if len({path.resolve() for path in args.files}) != len(args.files):
        parser.error("each input file must be specified once")
    try:
        rows = summarize(args.files, args.benchmark, args.metric, groups, args.drop_first_frame)
        writer = csv.writer(sys.stdout)
        writer.writerow(groups + ["runs", "rows", f"median_{args.metric}", f"min_run_{args.metric}", f"max_run_{args.metric}"])
        writer.writerows(rows)
    except (OSError, ValueError) as error:
        parser.exit(1, f"Error: {error}\n")


if __name__ == "__main__":
    main()
