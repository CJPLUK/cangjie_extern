#!/usr/bin/env python3
"""Extract inline JavaScript and CSS from the bundled presentation."""

import argparse
from html.parser import HTMLParser
import json
from pathlib import Path
import re


class ResourceInventory(HTMLParser):
    def __init__(self):
        super().__init__()
        self.external = []
        self.embedded_images = 0

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        for attribute in ("src", "href"):
            value = attrs.get(attribute, "")
            if value.startswith("data:"):
                if tag == "img":
                    self.embedded_images += 1
            elif value and not value.startswith("#"):
                self.external.append({"tag": tag, "attribute": attribute, "value": value})


def extract(html, destination):
    if destination.exists():
        raise ValueError("Choose a new destination directory")
    inventory = ResourceInventory()
    inventory.feed(html)
    files = []
    for tag, suffix in (("script", "js"), ("style", "css")):
        pattern = re.compile(r"<" + tag + r"\b([^>]*)>(.*?)</" + tag + r"\s*>", re.I | re.S)
        blocks = [body for attributes, body in pattern.findall(html) if not re.search(r"\bsrc\s*=", attributes, re.I)]
        for index, body in enumerate(blocks, 1):
            name = f"interop.inline.{suffix}" if len(blocks) == 1 else f"interop.inline-{index}.{suffix}"
            files.append((name, body))
    if not files:
        raise ValueError("No inline scripts or styles found")
    destination.mkdir(parents=True, exist_ok=False)
    for name, body in files:
        (destination / name).write_text(body, encoding="utf-8")
    manifest = {
        "inline_files": [name for name, body in files],
        "embedded_images": inventory.embedded_images,
        "external_references": inventory.external,
    }
    (destination / "assets.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("html", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    try:
        result = extract(args.html.read_text(encoding="utf-8"), args.destination)
        print(json.dumps(result, indent=2))
    except (OSError, ValueError) as error:
        parser.exit(1, f"Error: {error}\n")


if __name__ == "__main__":
    main()
