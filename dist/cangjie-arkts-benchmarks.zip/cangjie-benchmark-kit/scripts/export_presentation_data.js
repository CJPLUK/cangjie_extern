#!/usr/bin/env node
'use strict';

// Added utility: the original HTML stores DATA and rendering code inline.
const fs = require('node:fs');
const vm = require('node:vm');

function exportData(html) {
  const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi)];
  const matches = scripts.flatMap(script => [...script[1].matchAll(/\bconst\s+DATA\s*=\s*(\{[\s\S]*?\n\});/g)]);
  if (matches.length !== 1) {
    throw new Error('Expected exactly one DATA object in the presentation');
  }
  return vm.runInNewContext('(' + matches[0][1] + ')', Object.create(null), {
    timeout: 1000,
    contextCodeGeneration: { strings: false, wasm: false }
  });
}

if (require.main === module) {
  if (process.argv.length !== 3) {
    process.stderr.write('Usage: node export_presentation_data.js interop.html\n');
    process.exitCode = 1;
  } else {
    try {
      const data = exportData(fs.readFileSync(process.argv[2], 'utf8'));
      process.stdout.write(JSON.stringify(data, null, 2) + '\n');
    } catch (error) {
      process.stderr.write('Error: ' + error.message + '\n');
      process.exitCode = 1;
    }
  }
}

module.exports = { exportData };
